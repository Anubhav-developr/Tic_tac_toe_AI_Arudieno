# Tic_tac_toe_AI_Arudieno
This is powerful AI based tic tac toe game working with arudieno.(hardware part is still in progress)
This game have an unbeatable AI which i made through MINIMAX ALGORITHM blended with javascript, it contain two pages 
1) first page : this is the entry part of our game(under development )
2) game page : this is the main game page


![game](https://user-images.githubusercontent.com/71844334/107122361-56d77300-68bd-11eb-86fd-45ba44d2c2f1.png)
This is the game interface


![ezgif com-gif-maker (1)](https://user-images.githubusercontent.com/71844334/107122976-ff3b0680-68c0-11eb-9426-8601fa624f18.gif)

Future destiny of this artifact might be to make it react and hardware friendly
we can make its look more attractive and appealing by classic CSS and we can add more pages to it and we could fortunately make log of past attempts for a user by saving his/er data to the browser storage and we can host our web game using github to the server and make this game alive on the internet.
also we can also add specific sounds after user's move and can delay our robot's move and can add animation for better interface of our game.





